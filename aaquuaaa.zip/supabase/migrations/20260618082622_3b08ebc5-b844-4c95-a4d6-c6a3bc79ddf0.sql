
-- Site settings (key/value store for social links, about content, hero text, stats overrides)
CREATE TABLE public.site_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_settings TO anon, authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "site_settings public read" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);

-- Videos
CREATE TABLE public.videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  youtube_url TEXT NOT NULL,
  video_id TEXT NOT NULL,
  title TEXT,
  thumbnail TEXT,
  channel TEXT,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.videos TO anon, authenticated;
GRANT ALL ON public.videos TO service_role;
ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "videos public read" ON public.videos FOR SELECT TO anon, authenticated USING (true);

-- Community posts
CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url TEXT,
  text TEXT NOT NULL,
  link TEXT,
  like_count INT NOT NULL DEFAULT 0,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.posts TO anon, authenticated;
GRANT ALL ON public.posts TO service_role;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "posts public read" ON public.posts FOR SELECT TO anon, authenticated USING (true);

-- Comments
CREATE TABLE public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL,
  comment TEXT NOT NULL,
  avatar_url TEXT,
  pinned BOOLEAN NOT NULL DEFAULT false,
  hidden BOOLEAN NOT NULL DEFAULT false,
  is_special BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.comments TO anon, authenticated;
GRANT ALL ON public.comments TO service_role;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "comments public read visible" ON public.comments FOR SELECT TO anon, authenticated USING (hidden = false);
CREATE POLICY "comments public insert basic" ON public.comments FOR INSERT TO anon, authenticated
  WITH CHECK (
    is_special = false
    AND pinned = false
    AND hidden = false
    AND avatar_url IS NULL
    AND length(username) BETWEEN 1 AND 40
    AND length(comment) BETWEEN 1 AND 400
  );

-- Contact messages (write-only for public)
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL,
  email TEXT NOT NULL,
  discord TEXT,
  topic TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT INSERT ON public.messages TO anon, authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages public insert validated" ON public.messages FOR INSERT TO anon, authenticated
  WITH CHECK (
    length(username) BETWEEN 1 AND 60
    AND length(email) BETWEEN 3 AND 200
    AND email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND length(message) BETWEEN 1 AND 2000
    AND topic IN ('Sponsor', 'General', 'Fan Talks', 'Others')
  );

-- Milestones
CREATE TABLE public.milestones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  label TEXT NOT NULL,
  achieved BOOLEAN NOT NULL DEFAULT false,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.milestones TO anon, authenticated;
GRANT ALL ON public.milestones TO service_role;
ALTER TABLE public.milestones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "milestones public read" ON public.milestones FOR SELECT TO anon, authenticated USING (true);

-- Seed defaults
INSERT INTO public.site_settings (key, value) VALUES
  ('hero', '{"title":"RealAaquif","subtitle":"Gaming • Minecraft • Content Creation","tagline":"Premium gaming content, built for the elite."}'::jsonb),
  ('about', '{"heading":"The Creator","body":"RealAaquif is a Minecraft creator and gaming storyteller. From clutch survival runs to community-driven adventures, every video is built to feel cinematic, sharp, and personal.","niche":"Minecraft • Gameplay • Community","mission":"Build the warmest, sharpest gaming community on the internet."}'::jsonb),
  ('social', '{"youtube":"https://youtube.com/@RealAaquif","discord":"https://discord.gg/realaaquif","instagram":"https://instagram.com/realaaquif"}'::jsonb),
  ('stats', '{"subscribers":"12.4K","views":"1.2M","videos":"86","discord":"3.1K","years":"3"}'::jsonb);

INSERT INTO public.milestones (label, achieved, position) VALUES
  ('1K Subscribers', true, 1),
  ('10K Subscribers', true, 2),
  ('50K Subscribers', false, 3),
  ('100K Subscribers', false, 4);

INSERT INTO public.comments (username, comment, is_special, avatar_url, pinned) VALUES
  ('Aaquif', 'Welcome to the portal — built for the community. Drop a comment below 🔥', true, NULL, true);
