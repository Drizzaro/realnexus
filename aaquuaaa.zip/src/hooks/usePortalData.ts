import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getSettings, getVideos, getPosts, getComments, getMilestones } from "@/lib/public.functions";
import { DEFAULT_SETTINGS, type SiteSettings } from "@/lib/portal-types";

export type VideoRow = {
  id: string;
  youtube_url: string;
  video_id: string;
  title: string | null;
  thumbnail: string | null;
  channel: string | null;
  created_at: string;
};

export type PostRow = {
  id: string;
  text: string;
  image_url: string | null;
  link: string | null;
  like_count: number;
  created_at: string;
};

export type CommentRow = {
  id: string;
  username: string;
  comment: string;
  avatar_url: string | null;
  pinned: boolean;
  hidden: boolean;
  is_special: boolean;
  created_at: string;
};

export type MilestoneRow = {
  id: string;
  label: string;
  achieved: boolean;
  position: number;
};

export function useSettings() {
  const fetchSettings = useServerFn(getSettings);
  return useQuery({
    queryKey: ["site_settings"],
    queryFn: async (): Promise<SiteSettings> => {
      const data = await fetchSettings();
      const merged = JSON.parse(JSON.stringify(DEFAULT_SETTINGS)) as Record<string, Record<string, unknown>>;
      for (const row of data ?? []) {
        const k = row.key as string;
        if (k in merged) {
          merged[k] = { ...merged[k], ...(row.value as Record<string, unknown>) };
        }
      }
      return merged as unknown as SiteSettings;
    },
    staleTime: 30_000,
  });
}

export function useVideos() {
  const fetchVideos = useServerFn(getVideos);
  return useQuery({
    queryKey: ["videos"],
    queryFn: async (): Promise<VideoRow[]> => {
      return (await fetchVideos() as VideoRow[]) ?? [];
    },
    staleTime: 15_000,
  });
}

export function usePosts() {
  const fetchPosts = useServerFn(getPosts);
  return useQuery({
    queryKey: ["posts"],
    queryFn: async (): Promise<PostRow[]> => {
      return (await fetchPosts() as PostRow[]) ?? [];
    },
    staleTime: 15_000,
  });
}

export function useComments() {
  const fetchComments = useServerFn(getComments);
  return useQuery({
    queryKey: ["comments"],
    queryFn: async (): Promise<CommentRow[]> => {
      return (await fetchComments() as CommentRow[]) ?? [];
    },
    staleTime: 10_000,
  });
}

export function useMilestones() {
  const fetchMilestones = useServerFn(getMilestones);
  return useQuery({
    queryKey: ["milestones"],
    queryFn: async (): Promise<MilestoneRow[]> => {
      return (await fetchMilestones() as MilestoneRow[]) ?? [];
    },
    staleTime: 30_000,
  });
}

export function timeAgo(iso: string): string {
  const t = new Date(iso).getTime();
  const s = Math.max(1, Math.floor((Date.now() - t) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  const mo = Math.floor(d / 30);
  if (mo < 12) return `${mo}mo ago`;
  return `${Math.floor(mo / 12)}y ago`;
}
