import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { verifyAdmin } from "@/lib/admin.functions";

interface AdminCtx {
  isAdmin: boolean;
  code: string | null;
  open: boolean;
  setOpen: (v: boolean) => void;
  login: (code: string) => Promise<boolean>;
  logout: () => void;
}

const Ctx = createContext<AdminCtx>({
  isAdmin: false,
  code: null,
  open: false,
  setOpen: () => {},
  login: async () => false,
  logout: () => {},
});

const STORAGE_KEY = "ra_admin_code_v1";

export function AdminProvider({ children }: { children: ReactNode }) {
  const [code, setCode] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const verify = useServerFn(verifyAdmin);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return;
    verify({ data: { code: saved } })
      .then((r) => {
        if (r.ok) setCode(saved);
        else localStorage.removeItem(STORAGE_KEY);
      })
      .catch(() => localStorage.removeItem(STORAGE_KEY));
  }, [verify]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handler = (e: KeyboardEvent) => {
      if (e.shiftKey && (e.key === "A" || e.key === "a") && !e.ctrlKey && !e.metaKey) {
        const tag = (e.target as HTMLElement)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        e.preventDefault();
        setOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const login = async (input: string) => {
    const r = await verify({ data: { code: input } });
    if (r.ok) {
      setCode(input);
      localStorage.setItem(STORAGE_KEY, input);
      setOpen(false);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCode(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <Ctx.Provider value={{ isAdmin: !!code, code, open, setOpen, login, logout }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAdmin = () => useContext(Ctx);
