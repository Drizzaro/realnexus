import { motion } from "framer-motion";
import { Play } from "lucide-react";
import { Reveal } from "./Reveal";
import { useVideos, timeAgo, type VideoRow } from "@/hooks/usePortalData";
import { useAdmin } from "@/hooks/useAdmin";
import { useServerFn } from "@tanstack/react-start";
import { deleteVideo } from "@/lib/admin.functions";
import { useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";

export function VideosSection() {
  const { data: videos = [], isLoading } = useVideos();
  return (
    <section id="videos" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <SectionHeader
            eyebrow="Recent drops"
            title="Latest Uploads"
            sub="Hand-picked from the channel — the freshest cuts."
          />
        </Reveal>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="glass rounded-2xl aspect-video animate-pulse" />
            ))}
          </div>
        ) : videos.length === 0 ? (
          <EmptyState message="No videos yet. Admin can add YouTube URLs." />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {videos.map((v, i) => (
              <Reveal key={v.id} delay={Math.min(i * 0.05, 0.3)}>
                <VideoCard video={v} />
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function VideoCard({ video }: { video: VideoRow }) {
  const { isAdmin, code } = useAdmin();
  const del = useServerFn(deleteVideo);
  const qc = useQueryClient();
  return (
    <motion.a
      href={video.youtube_url}
      target="_blank"
      rel="noreferrer"
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 320, damping: 24 }}
      className="shine group block overflow-hidden rounded-2xl glass-strong"
    >
      <div className="relative aspect-video overflow-hidden">
        {video.thumbnail ? (
          <img
            src={video.thumbnail}
            alt={video.title ?? "Video thumbnail"}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src =
                `https://i.ytimg.com/vi/${video.video_id}/hqdefault.jpg`;
            }}
          />
        ) : (
          <div className="h-full w-full bg-muted" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div
            className="grid place-items-center h-14 w-14 rounded-full"
            style={{ background: "var(--gradient-red)", boxShadow: "var(--shadow-red)" }}
          >
            <Play className="h-5 w-5 fill-white text-white" />
          </div>
        </div>
        {isAdmin && (
          <button
            onClick={(e) => {
              e.preventDefault();
              if (!code) return;
              if (!confirm("Delete this video?")) return;
              del({ data: { code, id: video.id } }).then(() =>
                qc.invalidateQueries({ queryKey: ["videos"] }),
              );
            }}
            className="absolute top-3 right-3 rounded-full bg-black/60 backdrop-blur p-2 text-white hover:bg-destructive transition-colors"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
      <div className="p-4">
        <div className="line-clamp-2 text-sm font-medium">
          {video.title ?? "Untitled video"}
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>{video.channel ?? "YouTube"}</span>
          <span>{timeAgo(video.created_at)}</span>
        </div>
      </div>
    </motion.a>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  sub,
}: {
  eyebrow: string;
  title: string;
  sub?: string;
}) {
  return (
    <div className="mb-10 md:mb-14">
      <div className="text-[11px] uppercase tracking-[0.3em] text-primary/80 font-medium">
        {eyebrow}
      </div>
      <h2 className="mt-2 font-display text-4xl md:text-5xl font-bold tracking-tight">
        {title}
      </h2>
      {sub && (
        <p className="mt-3 max-w-xl text-sm md:text-base text-muted-foreground">{sub}</p>
      )}
    </div>
  );
}

export function EmptyState({ message }: { message: string }) {
  return (
    <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">
      {message}
    </div>
  );
}
