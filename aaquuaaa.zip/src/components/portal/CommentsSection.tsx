import { useState } from "react";
import { motion } from "framer-motion";
import { Pin, Trash2, EyeOff, Eye, Sparkles, Send } from "lucide-react";
import { Reveal } from "./Reveal";
import { SectionHeader } from "./VideosSection";
import { useComments, timeAgo, type CommentRow } from "@/hooks/usePortalData";
import { useAdmin } from "@/hooks/useAdmin";
import { useServerFn } from "@tanstack/react-start";
import { adminCommentAction } from "@/lib/admin.functions";
import { addComment } from "@/lib/public.functions";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const RL_KEY = "ra_last_comment_at";

export function CommentsSection() {
  const { data: comments = [] } = useComments();
  const qc = useQueryClient();
  const [username, setUsername] = useState("");
  const [comment, setComment] = useState("");
  const [sending, setSending] = useState(false);

  const addCommentFn = useServerFn(addComment);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const last = Number(localStorage.getItem(RL_KEY) ?? 0);
    if (Date.now() - last < 15_000) {
      toast.error("Slow down a sec.");
      return;
    }
    if (!username.trim() || !comment.trim()) return;
    setSending(true);
    try {
      await addCommentFn({
        data: {
          username: username.trim().slice(0, 40),
          comment: comment.trim().slice(0, 400),
        }
      });
      localStorage.setItem(RL_KEY, String(Date.now()));
      setComment("");
      qc.invalidateQueries({ queryKey: ["comments"] });
      toast.success("Posted ⚡");
    } catch (error) {
      toast.error("Couldn't post.");
    } finally {
      setSending(false);
    }
  };

  // Split comments
  const featured = comments.filter(c => c.is_special);
  const normal = comments.filter(c => !c.is_special);

  // Build two scrolling rows for normal comments
  const half = Math.ceil(normal.length / 2);
  const row1 = normal.slice(0, Math.max(half, 4));
  const row2 = normal.slice(Math.max(half, 4));

  return (
    <section className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <SectionHeader
            eyebrow="The wall"
            title="Community Voices"
            sub="Drop a comment. Watch the wall live in real time."
          />
        </Reveal>

        <Reveal>
          <form
            onSubmit={submit}
            className="glass-strong rounded-2xl p-4 md:p-5 mb-10 flex flex-col md:flex-row gap-3"
          >
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Your name"
              maxLength={40}
              required
              className="md:w-44 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
            />
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Say something nice…"
              maxLength={400}
              required
              className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
            />
            <button
              type="submit"
              disabled={sending}
              className="shine inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
              style={{ background: "var(--gradient-red)" }}
            >
              <Send className="h-3.5 w-3.5" /> Post
            </button>
          </form>
        </Reveal>

        {featured.length > 0 && (
          <div className="mb-14">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="h-px bg-primary/30 w-16" />
              <span className="text-[10px] uppercase tracking-[0.3em] text-primary">Featured by Aaquif</span>
              <div className="h-px bg-primary/30 w-16" />
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              {featured.map((c, i) => (
                <CommentCard key={`${c.id}-${i}`} comment={c} />
              ))}
            </div>
          </div>
        )}

        {normal.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">
            Be the first to drop a comment.
          </div>
        ) : (
          <div className="space-y-5 overflow-hidden">
            <Marquee direction="left" comments={row1} />
            <Marquee direction="right" comments={row2.length ? row2 : row1} />
          </div>
        )}
      </div>
    </section>
  );
}

function Marquee({
  direction,
  comments,
}: {
  direction: "left" | "right";
  comments: CommentRow[];
}) {
  if (comments.length === 0) return null;
  const looped = [...comments, ...comments];
  return (
    <div className="relative overflow-hidden">
      <div
        className={
          direction === "left" ? "animate-marquee-left flex gap-4 w-max" : "animate-marquee-right flex gap-4 w-max"
        }
      >
        {looped.map((c, i) => (
          <CommentCard key={`${c.id}-${i}`} comment={c} />
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background to-transparent" />
    </div>
  );
}

function CommentCard({ comment }: { comment: CommentRow }) {
  const { isAdmin, code } = useAdmin();
  const act = useServerFn(adminCommentAction);
  const qc = useQueryClient();
  const special = comment.is_special;

  const run = (action: "delete" | "pin" | "unpin" | "hide" | "show") => {
    if (!code) return;
    act({ data: { code, id: comment.id, action } }).then(() =>
      qc.invalidateQueries({ queryKey: ["comments"] }),
    );
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      className={`shine relative w-[320px] shrink-0 rounded-2xl p-4 overflow-hidden ${
        special ? "glass-red" : "glass"
      }`}
      style={
        special
          ? {
              boxShadow:
                "0 0 0 1px oklch(0.58 0.22 25 / 0.35), 0 14px 40px -10px oklch(0.58 0.22 25 / 0.45)",
            }
          : undefined
      }
    >
      {special && (
        <div className="absolute top-3 right-3 inline-flex items-center gap-1 text-[9px] uppercase font-bold tracking-[0.1em] text-white bg-primary px-2 py-0.5 rounded shadow-[0_0_10px_var(--color-primary-glow)]">
          <Sparkles className="h-3 w-3" /> FEATURED
        </div>
      )}
      <div className="flex items-center gap-3">
        {special && (
          comment.avatar_url ? (
            <img src={comment.avatar_url} alt="" className="h-9 w-9 rounded-full object-cover" />
          ) : (
            <div
              className="h-9 w-9 rounded-full grid place-items-center text-xs font-bold text-white shadow-[0_0_15px_var(--color-primary-glow)]"
              style={{ background: "var(--gradient-red)" }}
            >
              {comment.username.charAt(0).toUpperCase()}
            </div>
          )
        )}
        <div className="flex-1 min-w-0">
          <div className={`text-sm font-medium truncate ${special ? "text-primary" : ""}`}>
            {special ? `@${comment.username}` : comment.username}
          </div>
          {/* Normal comments show time ago next to name or below, let's keep it below */}
          {!special && <div className="text-[10px] text-muted-foreground">{timeAgo(comment.created_at)}</div>}
        </div>
        {comment.pinned && !special && <Pin className="h-3 w-3 text-primary" />}
      </div>
      <p className={`mt-3 text-sm line-clamp-3 ${special ? "text-white font-medium" : "text-foreground/90"}`}>
        {comment.comment}
      </p>
      {special && <div className="mt-3 text-[10px] text-muted-foreground">{new Date(comment.created_at).toLocaleDateString()}</div>}
      
      {isAdmin && (
        <div className="mt-3 flex gap-1.5">
          <IconBtn onClick={() => run(comment.pinned ? "unpin" : "pin")} title="Pin">
            <Pin className="h-3 w-3" />
          </IconBtn>
          <IconBtn onClick={() => run(comment.hidden ? "show" : "hide")} title="Hide">
            {comment.hidden ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
          </IconBtn>
          <IconBtn
            onClick={() => confirm("Delete?") && run("delete")}
            title="Delete"
            danger
          >
            <Trash2 className="h-3 w-3" />
          </IconBtn>
        </div>
      )}
    </motion.div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`rounded-md p-1.5 transition-colors ${
        danger
          ? "bg-destructive/20 hover:bg-destructive text-destructive-foreground"
          : "bg-white/5 hover:bg-white/15"
      }`}
    >
      {children}
    </button>
  );
}
