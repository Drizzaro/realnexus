import { useEffect, useRef, useState } from "react";
import { Reveal } from "./Reveal";
import { SectionHeader } from "./VideosSection";
import { useMilestones } from "@/hooks/usePortalData";
import type { SiteSettings } from "@/lib/portal-types";
import { Check, Sparkles } from "lucide-react";

function parseNumber(v: string): { num: number; suffix: string } {
  const m = v.match(/^([\d.]+)\s*([A-Za-z%+]*)$/);
  if (!m) return { num: 0, suffix: v };
  return { num: parseFloat(m[1]), suffix: m[2] };
}

function Counter({ value }: { value: string }) {
  const { num, suffix } = parseNumber(value);
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let started = false;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !started) {
          started = true;
          const start = performance.now();
          const dur = 1400;
          const tick = () => {
            const t = Math.min(1, (performance.now() - start) / dur);
            const eased = 1 - Math.pow(1 - t, 3);
            setN(num * eased);
            if (t < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
        }
      });
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, [num]);
  const decimals = num < 10 && num % 1 !== 0 ? 1 : 0;
  return (
    <span ref={ref} className="tabular-nums">
      {n.toFixed(decimals)}
      {suffix}
    </span>
  );
}

export function StatsSection({ settings }: { settings: SiteSettings }) {
  const { data: milestones = [] } = useMilestones();
  const items = [
    { label: "Subscribers", value: settings.stats.subscribers },
    { label: "Total Views", value: settings.stats.views },
    { label: "Videos", value: settings.stats.videos },
    { label: "Discord", value: settings.stats.discord },
    { label: "Years Active", value: settings.stats.years },
  ];
  return (
    <section id="milestones" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <SectionHeader
            eyebrow="By the numbers"
            title="Milestones & Stats"
            sub="The growth, the milestones, the road ahead."
          />
        </Reveal>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-12">
          {items.map((it, i) => (
            <Reveal key={it.label} delay={i * 0.05}>
              <div className="glass-strong shine rounded-2xl p-5">
                <div className="font-display text-3xl md:text-4xl font-bold">
                  <Counter value={it.value} />
                </div>
                <div className="mt-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  {it.label}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {milestones.length > 0 && (
          <Reveal>
            <div className="glass-red rounded-3xl p-6 md:p-8">
              <div className="text-[11px] uppercase tracking-[0.3em] text-pastel/90 mb-5">
                Milestone Timeline
              </div>
              <div className="relative">
                <div className="absolute left-0 right-0 top-5 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {milestones.map((m) => (
                    <div key={m.id} className="relative flex flex-col items-center text-center">
                      <div
                        className={`relative z-10 grid h-10 w-10 place-items-center rounded-full ${m.achieved
                            ? "text-white"
                            : "text-muted-foreground"
                          }`}
                        style={
                          m.achieved
                            ? {
                              background: "var(--gradient-red)",
                              boxShadow: "var(--shadow-red)",
                            }
                            : {
                              background: "oklch(0.18 0.01 20)",
                              border: "1px solid oklch(1 0 0 / 0.1)",
                            }
                        }
                      >
                        {m.achieved ? <Check className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
                      </div>
                      <div className="mt-3 text-sm font-medium">{m.label}</div>
                      <div className="mt-1 text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                        {m.achieved ? "Achieved" : "In progress"}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        )}
      </div>
    </section>
  );
}
