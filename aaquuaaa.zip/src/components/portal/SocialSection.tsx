import { motion } from "framer-motion";
import { Youtube, MessageCircle, Instagram } from "lucide-react";
import { Reveal } from "./Reveal";
import { SectionHeader } from "./VideosSection";
import type { SiteSettings } from "@/lib/portal-types";

export function SocialSection({ settings }: { settings: SiteSettings }) {
  const links = [
    {
      key: "youtube",
      label: "YouTube",
      url: settings.social.youtube,
      Icon: Youtube,
      sub: "Watch every drop",
    },
    {
      key: "discord",
      label: "Discord",
      url: settings.social.discord,
      Icon: MessageCircle,
      sub: "Join the community",
    },
    {
      key: "instagram",
      label: "Instagram",
      url: settings.social.instagram,
      Icon: Instagram,
      sub: "Behind the lens",
    },
  ];
  return (
    <section className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <SectionHeader
            eyebrow="Find me everywhere"
            title="Connect"
            sub="One creator. Three feeds. Pick yours."
          />
        </Reveal>
        <div className="grid md:grid-cols-3 gap-5">
          {links.map((l, i) => (
            <Reveal key={l.key} delay={i * 0.07}>
              <motion.a
                href={l.url}
                target="_blank"
                rel="noreferrer"
                whileHover={{ scale: 1.02, y: -2 }}
                transition={{ type: "spring", stiffness: 320, damping: 22 }}
                className="shine group relative block rounded-2xl glass-strong p-6 overflow-hidden"
              >
                <div
                  className="absolute -top-12 -right-12 h-40 w-40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background:
                      "radial-gradient(circle, oklch(0.58 0.22 25 / 0.35), transparent 70%)",
                    filter: "blur(20px)",
                  }}
                />
                <div className="relative flex items-center gap-4">
                  <div
                    className="grid h-12 w-12 place-items-center rounded-xl"
                    style={{
                      background: "var(--gradient-red)",
                      boxShadow: "var(--shadow-red)",
                    }}
                  >
                    <l.Icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <div className="font-display text-lg font-semibold">{l.label}</div>
                    <div className="text-xs text-muted-foreground">{l.sub}</div>
                  </div>
                </div>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
