import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useAdmin } from "@/hooks/useAdmin";
import { Shield } from "lucide-react";

const SECTIONS = [
  { id: "home", label: "Home" },
  { id: "videos", label: "Videos" },
  { id: "community", label: "Community" },
  { id: "milestones", label: "Milestones" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("home");
  const { isAdmin, setOpen, logout } = useAdmin();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => {
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, []);

  return (
    <motion.header
      initial={{ y: -32, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, delay: 0.4, ease: [0.2, 0.7, 0.2, 1] }}
      className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-4"
    >
      <nav
        className={`glass-strong relative flex items-center gap-1 rounded-full px-2 py-2 transition-all duration-500 ${
          scrolled ? "shadow-[0_8px_40px_-8px_oklch(0_0_0/0.6)]" : ""
        }`}
      >
        <a
          href="#home"
          className="px-4 py-2 font-display font-bold text-sm tracking-tight"
        >
          Real<span className="text-gradient-red">Aaquif</span>
        </a>
        <div className="hidden md:flex items-center relative">
          {SECTIONS.map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              className={`relative px-4 py-2 text-xs font-medium tracking-wide transition-colors ${
                active === s.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {active === s.id && (
                <motion.span
                  layoutId="nav-pill"
                  className="absolute inset-0 rounded-full glass-red"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative">{s.label}</span>
            </a>
          ))}
        </div>
        <button
          onClick={() => (isAdmin ? logout() : setOpen(true))}
          className="ml-1 rounded-full p-2 text-muted-foreground hover:text-foreground transition-colors"
          aria-label={isAdmin ? "Sign out admin" : "Admin"}
          title={isAdmin ? "Admin (click to sign out)" : "Admin"}
        >
          <Shield className={`h-4 w-4 ${isAdmin ? "text-primary" : ""}`} />
        </button>
      </nav>
    </motion.header>
  );
}
