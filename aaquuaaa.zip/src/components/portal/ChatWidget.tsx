import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessageSquare, X, Send } from "lucide-react";
import { useSettings } from "@/hooks/usePortalData";

type Msg = { from: "bot" | "user"; text: string; ts: number };

// Fully offline scripted bot — no API, no deps, no key.
function reply(input: string, ctx: { youtube: string; discord: string; instagram: string }) {
  const t = input.toLowerCase();
  const has = (...keys: string[]) => keys.some((k) => t.includes(k));
  if (has("hi", "hello", "hey", "yo", "sup"))
    return "Hey! Welcome to the RealAaquif portal. Ask me about videos, the channel, or how to join the community.";
  if (has("discord", "server", "community"))
    return `The Discord is live and very active — jump in here: ${ctx.discord}`;
  if (has("youtube", "channel", "subscribe", "video"))
    return `Latest uploads are right above on the page. The channel: ${ctx.youtube}`;
  if (has("insta", "instagram", "ig"))
    return `Behind-the-scenes lives on Instagram: ${ctx.instagram}`;
  if (has("sponsor", "brand", "collab", "business"))
    return "For sponsorships, scroll to Contact and pick the 'Sponsor' topic — I read every one.";
  if (has("minecraft", "skin", "game"))
    return "Yes — RealAaquif is a Minecraft creator. The 3D head above is the actual skin used in videos.";
  if (has("contact", "email", "message"))
    return "Use the Contact form below — drop your topic and message and it lands straight in the inbox.";
  if (has("admin", "shift", "ctrl"))
    return "Admin tools live behind a secret keystroke. Only the channel owner can use them.";
  if (has("who", "real aaquif", "about"))
    return "RealAaquif is a creator focused on Minecraft and gaming storytelling — clutch survival runs, cinematic builds, real community.";
  if (has("thanks", "thank you", "thx"))
    return "Anytime ⚡ Have fun exploring the portal.";
  return "I can help with channel info, social links, latest uploads, and community questions. Try asking about Discord, videos, or Minecraft.";
}

const QUICK = ["Channel info", "Social links", "Latest uploads", "Community"];

export function ChatWidget() {
  const { data: settings } = useSettings();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    { from: "bot", text: "Hey — I'm Aaquif's assistant. What's up?", ts: Date.now() },
  ]);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 1e9, behavior: "smooth" });
  }, [msgs, typing, open]);

  const send = (raw: string) => {
    const v = raw.trim();
    if (!v) return;
    setMsgs((m) => [...m, { from: "user", text: v, ts: Date.now() }]);
    setText("");
    setTyping(true);
    const social = settings?.social ?? {
      youtube: "https://youtube.com",
      discord: "https://discord.gg",
      instagram: "https://instagram.com",
    };
    const r = reply(v, social);
    setTimeout(() => {
      setMsgs((m) => [...m, { from: "bot", text: r, ts: Date.now() }]);
      setTyping(false);
    }, 600 + Math.min(1400, r.length * 12));
  };

  return (
    <>
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 2.4, type: "spring", stiffness: 260, damping: 18 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen((o) => !o)}
        className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full text-white"
        style={{ background: "var(--gradient-red)", boxShadow: "var(--shadow-red)" }}
        aria-label="Open chat"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="h-5 w-5" />
            </motion.span>
          ) : (
            <motion.span key="m" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <MessageSquare className="h-5 w-5" />
            </motion.span>
          )}
        </AnimatePresence>
        {!open && (
          <span className="absolute inset-0 rounded-full animate-pulse-ring pointer-events-none" style={{ boxShadow: "0 0 0 0 oklch(0.58 0.22 25 / 0.6)" }} />
        )}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.2, 0.7, 0.2, 1] }}
            className="fixed bottom-24 right-5 z-40 w-[min(380px,calc(100vw-2rem))] h-[520px] rounded-3xl glass-strong overflow-hidden flex flex-col"
          >
            <div
              className="p-4 border-b border-white/5 flex items-center gap-3"
              style={{ background: "linear-gradient(180deg, oklch(0.58 0.22 25 / 0.10), transparent)" }}
            >
              <div
                className="h-9 w-9 rounded-full grid place-items-center text-white"
                style={{ background: "var(--gradient-red)" }}
              >
                <MessageSquare className="h-4 w-4" />
              </div>
              <div>
                <div className="text-sm font-medium">Aaquif Support</div>
                <div className="text-[10px] text-muted-foreground flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-400" /> Online
                </div>
              </div>
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
              {msgs.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
                      m.from === "user"
                        ? "text-primary-foreground"
                        : "bg-white/5 text-foreground/90"
                    }`}
                    style={
                      m.from === "user"
                        ? { background: "var(--gradient-red)" }
                        : undefined
                    }
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {typing && (
                <div className="flex justify-start">
                  <div className="bg-white/5 rounded-2xl px-3 py-2 flex items-center gap-1">
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="block h-1.5 w-1.5 rounded-full bg-pastel"
                        style={{
                          animation: `typing-dot 1s ${i * 0.15}s infinite`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="px-3 pb-2 flex flex-wrap gap-1.5">
              {QUICK.map((q) => (
                <button
                  key={q}
                  onClick={() => send(q)}
                  className="text-[11px] rounded-full glass px-3 py-1 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(text);
              }}
              className="p-3 border-t border-white/5 flex gap-2"
            >
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Ask anything…"
                className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
              />
              <button
                type="submit"
                className="grid place-items-center h-9 w-9 rounded-xl text-white"
                style={{ background: "var(--gradient-red)" }}
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
