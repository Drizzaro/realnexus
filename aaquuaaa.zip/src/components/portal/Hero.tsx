import { motion } from "framer-motion";
import { Play, MessageCircle, Mail } from "lucide-react";
import { MinecraftHead } from "./MinecraftHead";
import type { SiteSettings } from "@/lib/portal-types";
import { formatStat } from "@/lib/portal-types";

export function Hero({ settings }: { settings: SiteSettings }) {
  const hero = settings.hero;
  const stats = settings.stats;
  const social = settings.social;

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 px-4 overflow-hidden"
    >
      {/* Floating particles */}
      <Particles />
      <div className="relative mx-auto max-w-6xl grid lg:grid-cols-[1.2fr_1fr] gap-16 items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7, ease: [0.2, 0.7, 0.2, 1] }}
            className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs text-muted-foreground mb-6"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-ring" />
            Live • Building the elite Minecraft community
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 28, filter: "blur(8px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 0.9, delay: 0.8, ease: [0.2, 0.7, 0.2, 1] }}
            className="font-display text-6xl md:text-8xl font-bold tracking-tight leading-[0.9]"
          >
            {hero.title.replace("Aaquif", "")}
            <span className="text-gradient-red">Aaquif</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.95 }}
            className="mt-5 text-base md:text-lg text-muted-foreground tracking-[0.18em] uppercase"
          >
            {hero.subtitle}
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.1 }}
            className="mt-6 max-w-xl text-base md:text-lg text-foreground/80 leading-relaxed"
          >
            {hero.tagline}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            <a
              href={social.youtube}
              target="_blank"
              rel="noreferrer"
              className="shine inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-medium text-primary-foreground"
              style={{ background: "var(--gradient-red)", boxShadow: "var(--shadow-red)" }}
            >
              <Play className="h-4 w-4 fill-current" /> Watch Latest Video
            </a>
            <a
              href={social.discord}
              target="_blank"
              rel="noreferrer"
              className="shine inline-flex items-center gap-2 rounded-full glass px-5 py-3 text-sm font-medium"
            >
              <MessageCircle className="h-4 w-4" /> Join Discord
            </a>
            <a
              href="#contact"
              className="shine inline-flex items-center gap-2 rounded-full glass px-5 py-3 text-sm font-medium"
            >
              <Mail className="h-4 w-4" /> Contact Me
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 1.35 }}
            className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3"
          >
            <Mini label="Subscribers" value={stats.subscribers} />
            <Mini label="Total Views" value={stats.views} />
            <Mini label="Videos" value={stats.videos} />
            <Mini label="Discord" value={stats.discord} />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.1, delay: 0.9, ease: [0.2, 0.7, 0.2, 1] }}
          className="relative flex justify-center"
        >
          <MinecraftHead />
        </motion.div>
      </div>
    </section>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-2xl p-4 shine">
      <div className="font-display text-2xl font-bold tabular-nums">{formatStat(value)}</div>
      <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mt-1">
        {label}
      </div>
    </div>
  );
}

function Particles() {
  // SSR-safe: use deterministic seeds, no Math.random in render
  const items = Array.from({ length: 22 }, (_, i) => {
    const seed = i * 137.508;
    const left = (seed * 9.7) % 100;
    const top = (seed * 5.3) % 100;
    const delay = (i * 0.31) % 6;
    const size = 2 + ((i * 7) % 4);
    return { left, top, delay, size, i };
  });
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {items.map((p) => (
        <span
          key={p.i}
          className="absolute rounded-full animate-float"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            background: "oklch(0.78 0.18 25 / 0.6)",
            boxShadow: "0 0 8px oklch(0.78 0.18 25 / 0.7)",
            animationDelay: `${p.delay}s`,
            animationDuration: `${4 + (p.i % 4)}s`,
          }}
        />
      ))}
    </div>
  );
}
