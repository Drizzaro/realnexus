import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export function Loading() {
  const [done, setDone] = useState(false);
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const start = performance.now();
    const duration = 1800;
    let raf = 0;
    const tick = () => {
      const t = Math.min(1, (performance.now() - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setPct(Math.round(eased * 100));
      if (t < 1) raf = requestAnimationFrame(tick);
      else setTimeout(() => setDone(true), 250);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7, ease: [0.2, 0.7, 0.2, 1] }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background"
        >
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "radial-gradient(circle at 50% 40%, oklch(0.58 0.22 25 / 0.18), transparent 60%)",
            }}
          />
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.2, 0.7, 0.2, 1] }}
            className="relative text-center"
          >
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight">
              Real<span className="text-gradient-red">Aaquif</span>
            </h1>
            <p className="mt-3 text-sm md:text-base text-muted-foreground tracking-[0.3em] uppercase">
              Welcomes You
            </p>
          </motion.div>
          <div className="mt-12 w-56 h-[2px] bg-white/10 overflow-hidden rounded-full">
            <div
              className="h-full"
              style={{
                width: `${pct}%`,
                background: "linear-gradient(90deg, white, oklch(0.70 0.22 22))",
                transition: "width 80ms linear",
                boxShadow: "0 0 12px oklch(0.70 0.22 22 / 0.6)",
              }}
            />
          </div>
          <div className="mt-3 text-xs text-muted-foreground tabular-nums">{pct}%</div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
