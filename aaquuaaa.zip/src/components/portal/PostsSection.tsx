import { motion } from "framer-motion";
import { Heart, ExternalLink, Trash2 } from "lucide-react";
import { Reveal } from "./Reveal";
import { SectionHeader, EmptyState } from "./VideosSection";
import { usePosts, timeAgo, type PostRow } from "@/hooks/usePortalData";
import { useAdmin } from "@/hooks/useAdmin";
import { useServerFn } from "@tanstack/react-start";
import { deletePost } from "@/lib/admin.functions";
import { useQueryClient } from "@tanstack/react-query";

export function PostsSection() {
  const { data: posts = [], isLoading } = usePosts();
  return (
    <section id="community" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <SectionHeader
            eyebrow="From the feed"
            title="Community Posts"
            sub="Live updates, polls, behind-the-scenes."
          />
        </Reveal>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="glass rounded-2xl h-64 animate-pulse" />
            ))}
          </div>
        ) : posts.length === 0 ? (
          <EmptyState message="No community posts yet." />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {posts.map((p, i) => (
              <Reveal key={p.id} delay={Math.min(i * 0.05, 0.3)}>
                <PostCard post={p} />
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function PostCard({ post }: { post: PostRow }) {
  const { isAdmin, code } = useAdmin();
  const del = useServerFn(deletePost);
  const qc = useQueryClient();
  const Component = post.link ? motion.a : motion.div;
  return (
    <Component
      href={post.link ?? undefined}
      target={post.link ? "_blank" : undefined}
      rel="noreferrer"
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 320, damping: 24 }}
      className="shine group block overflow-hidden rounded-2xl glass-strong"
    >
      {post.image_url && (
        <div className="relative aspect-[16/10] overflow-hidden">
          <img
            src={post.image_url}
            alt=""
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          {isAdmin && (
            <button
              onClick={(e) => {
                e.preventDefault();
                if (!code) return;
                if (!confirm("Delete this post?")) return;
                del({ data: { code, id: post.id } }).then(() =>
                  qc.invalidateQueries({ queryKey: ["posts"] }),
                );
              }}
              className="absolute top-3 right-3 rounded-full bg-black/60 backdrop-blur p-2 text-white hover:bg-destructive transition-colors"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      )}
      <div className="p-5">
        <p className="text-sm leading-relaxed text-foreground/90 line-clamp-5">{post.text}</p>
        <div className="mt-4 flex items-center justify-between text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Heart className="h-3 w-3 text-primary" /> {post.like_count}
          </span>
          <span className="inline-flex items-center gap-1.5">
            {timeAgo(post.created_at)}
            {post.link && <ExternalLink className="h-3 w-3" />}
          </span>
        </div>
      </div>
    </Component>
  );
}
