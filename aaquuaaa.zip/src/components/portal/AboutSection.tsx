import { Reveal } from "./Reveal";
import { SectionHeader } from "./VideosSection";
import type { SiteSettings } from "@/lib/portal-types";
import skinAsset from "@/assets/YOUTUBE_PFP.png";

export function AboutSection({ settings }: { settings: SiteSettings }) {
  const a = settings.about;
  return (
    <section id="about" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl grid lg:grid-cols-[1fr_1.3fr] gap-10 items-center">
        <Reveal>
          <div className="glass-red rounded-3xl p-6 relative overflow-hidden">
            <div className="aspect-square rounded-2xl overflow-hidden bg-black/60 grid place-items-center relative">
              <img
                src={skinAsset}
                alt="RealAaquif Minecraft skin"
                className="pixelated h-3/4 w-3/4 object-contain"
              />

            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {a.niche.split("•").map((n) => (
                <span
                  key={n}
                  className="rounded-full glass px-3 py-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground"
                >
                  {n.trim()}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <SectionHeader eyebrow="The story" title={a.heading} />
          <p className="text-base md:text-lg text-foreground/85 leading-relaxed">{a.body}</p>
          <div className="mt-8 glass rounded-2xl p-5">
            <div className="text-[10px] uppercase tracking-[0.3em] text-primary/80 mb-2">
              Mission
            </div>
            <p className="text-sm text-foreground/90">{a.mission}</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
