import { useEffect, useState } from "react";
import Particles from "@/components/portal/Particles";


export function Ambient() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <>
  
      <div className="fixed inset-0 -z-20 pointer-events-none">
        <Particles />
      {/* Subtle animated grid */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(oklch(1 0 0 / 0.4) 1px, transparent 1px), linear-gradient(90deg, oklch(1 0 0 / 0.4) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage: "radial-gradient(ellipse at 50% 30%, black 30%, transparent 75%)",
        }}
      />
      {/* Red ambient blobs */}
      <div
        className="absolute top-[-15%] left-[-10%] h-[55vmax] w-[55vmax] rounded-full animate-orb"
        style={{
          background:
            "radial-gradient(circle at center, oklch(0.58 0.22 25 / 0.18), transparent 60%)",
          filter: "blur(40px)",
        }}
      />
      <div
        className="absolute bottom-[-20%] right-[-15%] h-[60vmax] w-[60vmax] rounded-full animate-orb"
        style={{
          background:
            "radial-gradient(circle at center, oklch(0.45 0.20 22 / 0.18), transparent 60%)",
          filter: "blur(40px)",
          animationDelay: "-6s",
        }}
      />
      <div
        className="absolute top-[40%] left-[40%] h-[35vmax] w-[35vmax] rounded-full animate-orb"
        style={{
          background:
            "radial-gradient(circle at center, oklch(0.95 0.02 20 / 0.05), transparent 60%)",
          filter: "blur(60px)",
          animationDelay: "-12s",
        }}
      />
      
      {/* Small glowing sparks / particles */}
      {mounted && Array.from({ length: 50 }).map((_, i) => (
        <div
          key={`particle-${i}`}
          className="absolute rounded-full animate-float"
          style={{
            width: Math.random() * 3 + 2 + "px",
            height: Math.random() * 3 + 2 + "px",
            left: Math.random() * 100 + "%",
            top: Math.random() * 100 + "%",
            background: "oklch(0.85 0.15 23)", // Brighter core
            boxShadow: "0 0 10px 2px oklch(0.65 0.25 25 / 1)", // Stronger red glow
            animationDuration: Math.random() * 15 + 10 + "s",
            animationDelay: "-" + Math.random() * 15 + "s",
          }}
        />
      ))}

      {/* Noise overlay */}
      <div
        className="absolute inset-0 opacity-[0.04] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")",
        }}
      />
    </div>
    </>
  );
}
