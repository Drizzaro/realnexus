import { useState } from "react";
import { motion } from "framer-motion";
import { Reveal } from "./Reveal";
import { SectionHeader } from "./VideosSection";
import { z } from "zod";
import { useServerFn } from "@tanstack/react-start";
import { addMessage } from "@/lib/public.functions";
import { toast } from "sonner";

const Schema = z.object({
  username: z.string().trim().min(1, "Username required").max(60),
  email: z.string().trim().email("Invalid email").max(200),
  discord: z.string().trim().max(60).optional(),
  topic: z.enum(["Sponsor", "General", "Fan Talks", "Others"]),
  message: z.string().trim().min(4, "Tell me a bit more").max(2000),
});

const TOPICS = ["Sponsor", "General", "Fan Talks", "Others"] as const;

// Tiny client-side rate limit (anti-spam UX layer)
const LAST_SEND_KEY = "ra_last_msg_at";

export function ContactSection() {
  const [sending, setSending] = useState(false);
  const [form, setForm] = useState({
    username: "",
    email: "",
    discord: "",
    topic: "General" as (typeof TOPICS)[number],
    message: "",
  });

  const addMessageFn = useServerFn(addMessage);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const last = Number(localStorage.getItem(LAST_SEND_KEY) ?? 0);
    if (Date.now() - last < 30_000) {
      toast.error("Please wait a moment before sending again.");
      return;
    }
    const r = Schema.safeParse(form);
    if (!r.success) {
      toast.error(r.error.issues[0]?.message ?? "Invalid form");
      return;
    }
    setSending(true);
    try {
      await addMessageFn({
        data: {
          name: r.data.username,
          email: r.data.email,
          message: `[${r.data.topic}] ${r.data.discord ? `Discord: ${r.data.discord}\n` : ''}${r.data.message}`
        }
      });
      localStorage.setItem(LAST_SEND_KEY, String(Date.now()));
      toast.success("Message sent. Talk soon ⚡");
      setForm({ username: "", email: "", discord: "", topic: "General", message: "" });
    } catch (error) {
      toast.error("Couldn't send. Try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="contact" className="relative px-4 py-24">
      <div className="mx-auto max-w-3xl">
        <Reveal>
          <SectionHeader
            eyebrow="Reach out"
            title="Get in Touch"
            sub="Sponsorships, fan talks, collabs — drop a line."
          />
        </Reveal>
        <Reveal delay={0.1}>
          <form
            onSubmit={submit}
            className="glass-strong rounded-3xl p-6 md:p-8 space-y-4"
          >
            <div className="grid md:grid-cols-2 gap-4">
              <Field label="Username">
                <input
                  required
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  className="input"
                  placeholder="yourname"
                />
              </Field>
              <Field label="Email">
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="input"
                  placeholder="you@example.com"
                />
              </Field>
              <Field label="Discord (optional)">
                <input
                  value={form.discord}
                  onChange={(e) => setForm({ ...form, discord: e.target.value })}
                  className="input"
                  placeholder="username"
                />
              </Field>
              <Field label="Topic">
                <select
                  value={form.topic}
                  onChange={(e) =>
                    setForm({ ...form, topic: e.target.value as (typeof TOPICS)[number] })
                  }
                  className="input"
                >
                  {TOPICS.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
            <Field label="Message">
              <textarea
                required
                rows={5}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="input resize-none"
                placeholder="Say something nice…"
              />
            </Field>
            <motion.button
              whileTap={{ scale: 0.97 }}
              type="submit"
              disabled={sending}
              className="shine inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-medium text-primary-foreground disabled:opacity-50"
              style={{ background: "var(--gradient-red)", boxShadow: "var(--shadow-red)" }}
            >
              {sending ? "Sending…" : "Send Message"}
            </motion.button>
          </form>
        </Reveal>
      </div>
      <style>{`
        .input {
          width: 100%;
          background: oklch(0.12 0.01 20 / 0.6);
          border: 1px solid oklch(1 0 0 / 0.08);
          border-radius: 12px;
          padding: 12px 14px;
          color: inherit;
          font-size: 14px;
          outline: none;
          transition: border-color .2s, box-shadow .2s, background .2s;
        }
        .input:focus {
          border-color: oklch(0.58 0.22 25 / 0.6);
          box-shadow: 0 0 0 4px oklch(0.58 0.22 25 / 0.12);
          background: oklch(0.14 0.01 20 / 0.8);
        }
        .input::placeholder { color: oklch(0.55 0.02 20); }
      `}</style>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-1.5 block">
        {label}
      </span>
      {children}
    </label>
  );
}
