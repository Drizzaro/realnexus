import React from "react";

export default function Particles() {
  // SSR-safe: deterministic seeds, no Math.random in render
  const items = Array.from({ length: 22 }, (_, i) => {
    const seed = i * 137.508;
    const left = (seed * 9.7) % 100;
    const top = (seed * 5.3) % 100;
    const delay = (i * 0.31) % 6;
    const size = 2 + ((i * 7) % 4);
    return { left, top, delay, size, i };
  });
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {items.map(p => (
        <span
          key={p.i}
          className="absolute rounded-full animate-float"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            background: "oklch(0.78 0.18 25 / 0.6)",
            boxShadow: "0 0 8px oklch(0.78 0.18 25 / 0.7)",
            animationDelay: `${p.delay}s`,
            animationDuration: `${4 + (p.i % 4)}s`,
          }}
        />
      ))}
    </div>
  );
}
