import { useEffect, useRef } from "react";
import skinAsset from "@/assets/aaquif-skin.png";

/**
 * Minecraft head: 6-face CSS cube textured with the skin file.
 * Standard 64x64 skin layout — head occupies the top-left 32x16 px.
 * Face mapping (8x8 each):
 *   Top:    (8, 0)    Bottom: (16, 0)
 *   Right:  (0, 8)    Front:  (8, 8)    Left: (16, 8)    Back: (24, 8)
 * Outer hat layer mirrors at +32 in X.
 */
const SIZE = 180; // head edge in px
const SCALE = SIZE / 8;
const TEX = SIZE * 8; // 8x scale of original 64px texture

const baseFaces = [
  { name: "front", x: 8, y: 8, t: `translateZ(${SIZE / 2}px)` },
  { name: "back", x: 24, y: 8, t: `translateZ(-${SIZE / 2}px) rotateY(180deg)` },
  { name: "right", x: 0, y: 8, t: `translateX(${SIZE / 2}px) rotateY(90deg)` },
  { name: "left", x: 16, y: 8, t: `translateX(-${SIZE / 2}px) rotateY(-90deg)` },
  { name: "top", x: 8, y: 0, t: `translateY(-${SIZE / 2}px) rotateX(90deg)` },
  { name: "bottom", x: 16, y: 0, t: `translateY(${SIZE / 2}px) rotateX(-90deg)` },
];

const faces = baseFaces;
const overlayFaces = baseFaces.map(f => ({ ...f, x: f.x + 32 }));



export function MinecraftHead() {
  const wrap = useRef<HTMLDivElement>(null);
  const cube = useRef<HTMLDivElement>(null);
  const eyeL = useRef<HTMLDivElement>(null);
  const eyeR = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let rx = -8, ry = -10;
    let tx = rx, ty = ry;
    let raf = 0;
    const tick = () => {
      tx += (rx - tx) * 0.08;
      ty += (ry - ty) * 0.08;
      if (cube.current) {
        cube.current.style.transform = `rotateX(${tx}deg) rotateY(${ty}deg)`;
      }
      const eyeX = Math.max(-2, Math.min(2, ry * 0.12));
      const eyeY = Math.max(-1.5, Math.min(1.5, tx * -0.08));
      if (eyeL.current) eyeL.current.style.transform = `translate(${eyeX}px, ${eyeY}px)`;
      if (eyeR.current) eyeR.current.style.transform = `translate(${eyeX}px, ${eyeY}px)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const onMove = (e: MouseEvent) => {
      if (!wrap.current) return;
      const r = wrap.current.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dx = (e.clientX - cx) / window.innerWidth;
      const dy = (e.clientY - cy) / window.innerHeight;
      ry = Math.max(-35, Math.min(35, dx * 60));
      rx = Math.max(-25, Math.min(25, -dy * 45));
    };
    window.addEventListener("mousemove", onMove);

    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={wrap}
      className="relative flex items-center justify-center animate-float"
      style={{ width: SIZE * 1.6, height: SIZE * 1.6, perspective: 1000 }}
    >
      {/* Glow */}
      <div
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle at center, oklch(0.60 0.22 25 / 0.45), transparent 60%)",
          filter: "blur(30px)",
        }}
      />
      <div
        ref={cube}
        className="relative transition-transform duration-300 ease-out"
        style={{
          width: SIZE,
          height: SIZE,
          transformStyle: "preserve-3d",
        }}
      >
        {faces.map((f) => (
          <div
            key={f.name}
            className="absolute inset-0 pixelated"
            style={{
              width: SIZE,
              height: SIZE,
              backgroundImage: `url(${skinAsset})`,
              backgroundSize: `${TEX}px ${TEX}px`,
              backgroundPosition: `-${f.x * SCALE}px -${f.y * SCALE}px`,
              transform: f.t,
              boxShadow: "0 0 0 1px oklch(0 0 0 / 0.15) inset",
            }}
          >
            {/* eyes glow overlay on front only */}
            {f.name === "front" && (
              <>
                <div
                  ref={eyeL}
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: 6,
                    height: 6,
                    left: "27%",
                    top: "47%",
                    background: "oklch(0.78 0.18 25 / 0.9)",
                    boxShadow: "0 0 10px oklch(0.78 0.18 25 / 0.9)",
                    transition: "transform 60ms linear",
                  }}
                />
                <div
                  ref={eyeR}
                  className="absolute rounded-full pointer-events-none"
                  style={{
                    width: 6,
                    height: 6,
                    right: "27%",
                    top: "47%",
                    background: "oklch(0.78 0.18 25 / 0.9)",
                    boxShadow: "0 0 10px oklch(0.78 0.18 25 / 0.9)",
                    transition: "transform 60ms linear",
                  }}
                />
              </>
            )}
          </div>
        ))}
        {/* Overlay layer */}
        <div
          className="absolute inset-0"
          style={{
            transformStyle: "preserve-3d",
            transform: "scale(1.06)",
          }}
        >
          {overlayFaces.map((f) => (
            <div
              key={`overlay-${f.name}`}
              className="absolute inset-0 pixelated"
              style={{
                width: SIZE,
                height: SIZE,
                backgroundImage: `url(${skinAsset})`,
                backgroundSize: `${TEX}px ${TEX}px`,
                backgroundPosition: `-${f.x * SCALE}px -${f.y * SCALE}px`,
                transform: f.t,
                pointerEvents: "none",
              }}
            />
          ))}
        </div>
      </div>
      {/* base shadow */}
      <div
        className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full"
        style={{
          width: SIZE * 0.7,
          height: 14,
          background: "radial-gradient(ellipse, oklch(0 0 0 / 0.55), transparent 70%)",
          filter: "blur(6px)",
        }}
      />
    </div>
  );
}
