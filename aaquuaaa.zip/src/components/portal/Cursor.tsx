import { useEffect, useRef, useState } from "react";

export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const glow = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState(false);
  const [coarse, setCoarse] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(pointer: coarse)");
    setCoarse(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setCoarse(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  useEffect(() => {
    if (coarse) return;
    let x = window.innerWidth / 2;
    let y = window.innerHeight / 2;
    let rx = x, ry = y;
    let gx = x, gy = y;
    let raf = 0;

    const tick = () => {
      rx += (x - rx) * 0.2;
      ry += (y - ry) * 0.2;
      gx += (x - gx) * 0.08;
      gy += (y - gy) * 0.08;
      if (dot.current) dot.current.style.transform = `translate3d(${x - 4}px, ${y - 4}px, 0)`;
      if (ring.current) ring.current.style.transform = `translate3d(${rx - 18}px, ${ry - 18}px, 0)`;
      if (glow.current) glow.current.style.transform = `translate3d(${gx - 140}px, ${gy - 140}px, 0)`;
      raf = requestAnimationFrame(tick);
    };

    const move = (e: MouseEvent) => {
      x = e.clientX;
      y = e.clientY;
      const t = e.target as HTMLElement | null;
      const interactive = !!t?.closest("a,button,input,textarea,select,[role='button'],[data-cursor='hover']");
      setHover(interactive);
    };

    window.addEventListener("mousemove", move);
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, [coarse]);

  if (coarse) return null;

  return (
    <>
      {/* spotlight glow */}
      <div
        ref={glow}
        className="fixed left-0 top-0 z-[60] h-[280px] w-[280px] rounded-full pointer-events-none mix-blend-screen"
        style={{
          background:
            "radial-gradient(circle, oklch(0.70 0.22 22 / 0.18) 0%, transparent 65%)",
          filter: "blur(8px)",
        }}
      />
      {/* outer ring */}
      <div
        ref={ring}
        className="fixed left-0 top-0 z-[61] h-9 w-9 rounded-full pointer-events-none transition-[opacity,border-color,width,height] duration-200"
        style={{
          border: "1.5px solid oklch(0.82 0.08 18 / 0.85)",
          opacity: hover ? 1 : 0.7,
          boxShadow: hover
            ? "0 0 24px oklch(0.70 0.22 22 / 0.6)"
            : "0 0 12px oklch(0.70 0.22 22 / 0.35)",
          transform: "translate3d(-100px,-100px,0)",
        }}
      />
      {/* center dot */}
      <div
        ref={dot}
        className="fixed left-0 top-0 z-[62] h-2 w-2 rounded-full pointer-events-none"
        style={{
          background: "oklch(0.82 0.08 18)",
          boxShadow: "0 0 10px oklch(0.82 0.08 18 / 0.8)",
          transform: "translate3d(-100px,-100px,0)",
        }}
      />
    </>
  );
}
