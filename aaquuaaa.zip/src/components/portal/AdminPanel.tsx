import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Shield, X, KeyRound, Loader2, LogOut, Plus, Trash2, MessageSquare, Star, Award } from "lucide-react";
import { useAdmin } from "@/hooks/useAdmin";
import { useServerFn } from "@tanstack/react-start";
import {
  addVideo,
  addPost,
  updateSetting,
  adminAddSpecialComment,
  adminListMessages,
  adminDeleteMessage,
  adminUpsertMilestone,
  adminDeleteMilestone,
} from "@/lib/admin.functions";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { useSettings, useMilestones, timeAgo } from "@/hooks/usePortalData";
import { toast } from "sonner";

type Tab = "videos" | "posts" | "milestones" | "messages" | "settings" | "comments";

export function AdminPanel() {
  const { isAdmin, open, setOpen, login, logout, code } = useAdmin();
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<Tab>("videos");

  const submitCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const ok = await login(input.trim());
    setLoading(false);
    if (ok) {
      toast.success("Admin unlocked");
      setInput("");
    } else {
      toast.error("Wrong code");
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[80] flex items-center justify-center p-4"
          style={{ background: "oklch(0 0 0 / 0.7)", backdropFilter: "blur(10px)" }}
          onClick={() => setOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.94, y: 16, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.94, y: 16, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="glass-strong rounded-3xl w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col"
            style={{
              boxShadow:
                "0 30px 80px -20px oklch(0 0 0 / 0.6), 0 0 0 1px oklch(0.58 0.22 25 / 0.18), inset 0 1px 0 0 oklch(1 0 0 / 0.06)",
            }}
          >
            <div className="flex items-center justify-between p-5 border-b border-white/5">
              <div className="flex items-center gap-3">
                <div
                  className="h-9 w-9 rounded-xl grid place-items-center text-white"
                  style={{ background: "var(--gradient-red)" }}
                >
                  <Shield className="h-4 w-4" />
                </div>
                <div>
                  <div className="font-display font-semibold">Admin Portal</div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {isAdmin ? "Connected" : "Locked"}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isAdmin && (
                  <button
                    onClick={logout}
                    className="rounded-full glass px-3 py-1.5 text-xs inline-flex items-center gap-1.5"
                  >
                    <LogOut className="h-3 w-3" /> Sign out
                  </button>
                )}
                <button
                  onClick={() => setOpen(false)}
                  className="rounded-full glass p-2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {!isAdmin ? (
              <form onSubmit={submitCode} className="p-8 flex flex-col items-center text-center">
                <KeyRound className="h-10 w-10 text-primary mb-4" />
                <h3 className="font-display text-xl font-semibold">Enter Admin Portal Code</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-sm">
                  Tip: tap <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-[10px]">SHIFT</kbd> +
                  <kbd className="ml-1 px-1.5 py-0.5 rounded bg-white/10 text-[10px]">A</kbd> anywhere to open this.
                </p>
                <input
                  autoFocus
                  type="password"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="••••••••••••"
                  className="mt-6 w-full max-w-sm bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-center tracking-[0.3em] outline-none focus:border-primary/50"
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="shine mt-4 inline-flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-50"
                  style={{ background: "var(--gradient-red)" }}
                >
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
                  Unlock
                </button>
              </form>
            ) : (
              <>
                <div className="flex gap-1 px-4 pt-3 border-b border-white/5 overflow-x-auto">
                  {(["videos", "posts", "milestones", "comments", "messages", "settings"] as Tab[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => setTab(t)}
                      className={`px-3 py-2 text-xs font-medium capitalize rounded-t-lg transition-colors ${
                        tab === t ? "text-foreground bg-white/5" : "text-muted-foreground"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
                <div className="flex-1 overflow-y-auto p-5">
                  {tab === "videos" && code && <VideosTab code={code} />}
                  {tab === "posts" && code && <PostsTab code={code} />}
                  {tab === "milestones" && code && <MilestonesTab code={code} />}
                  {tab === "comments" && code && <CommentsTab code={code} />}
                  {tab === "messages" && code && <MessagesTab code={code} />}
                  {tab === "settings" && code && <SettingsTab code={code} />}
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function VideosTab({ code }: { code: string }) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const add = useServerFn(addVideo);
  const qc = useQueryClient();
  return (
    <div>
      <h4 className="font-display font-semibold mb-3">Add a video</h4>
      <div className="flex gap-2">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://youtube.com/watch?v=…"
          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
        />
        <button
          disabled={loading}
          onClick={async () => {
            if (!url.trim()) return;
            setLoading(true);
            try {
              await add({ data: { code, url: url.trim() } });
              toast.success("Video added");
              setUrl("");
              qc.invalidateQueries({ queryKey: ["videos"] });
            } catch (e) {
              toast.error((e as Error).message);
            } finally {
              setLoading(false);
            }
          }}
          className="rounded-xl px-4 py-2 text-sm font-medium text-white inline-flex items-center gap-1.5"
          style={{ background: "var(--gradient-red)" }}
        >
          <Plus className="h-3.5 w-3.5" /> Add
        </button>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Title, thumbnail, and channel name are fetched automatically from YouTube — no API key.
      </p>
      <p className="mt-4 text-xs text-muted-foreground">
        Manage existing videos right on the homepage — hover any video and click the trash icon.
      </p>
    </div>
  );
}

function PostsTab({ code }: { code: string }) {
  const [text, setText] = useState("");
  const [image, setImage] = useState("");
  const [link, setLink] = useState("");
  const [loading, setLoading] = useState(false);
  const add = useServerFn(addPost);
  const qc = useQueryClient();
  return (
    <div className="space-y-3">
      <h4 className="font-display font-semibold">Add community post</h4>
      <textarea
        rows={3}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Post text…"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50 resize-none"
      />
      <input
        value={image}
        onChange={(e) => setImage(e.target.value)}
        placeholder="Image URL (optional)"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
      />
      <input
        value={link}
        onChange={(e) => setLink(e.target.value)}
        placeholder="Source link (optional)"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
      />
      <button
        disabled={loading}
        onClick={async () => {
          if (!text.trim()) return;
          setLoading(true);
          try {
            await add({
              data: {
                code,
                text: text.trim(),
                image_url: image.trim() || null,
                link: link.trim() || null,
              },
            });
            toast.success("Post added");
            setText(""); setImage(""); setLink("");
            qc.invalidateQueries({ queryKey: ["posts"] });
          } catch (e) {
            toast.error((e as Error).message);
          } finally {
            setLoading(false);
          }
        }}
        className="rounded-xl px-4 py-2 text-sm font-medium text-white inline-flex items-center gap-1.5"
        style={{ background: "var(--gradient-red)" }}
      >
        <Plus className="h-3.5 w-3.5" /> Add post
      </button>
      <p className="text-xs text-muted-foreground">
        Manage existing posts on the homepage with the trash icon on hover.
      </p>
    </div>
  );
}

function MilestonesTab({ code }: { code: string }) {
  const { data: list = [] } = useMilestones();
  const qc = useQueryClient();
  const upsert = useServerFn(adminUpsertMilestone);
  const del = useServerFn(adminDeleteMilestone);
  const [label, setLabel] = useState("");
  return (
    <div className="space-y-3">
      <h4 className="font-display font-semibold flex items-center gap-2">
        <Award className="h-4 w-4 text-primary" /> Milestones
      </h4>
      <div className="flex gap-2">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="e.g. 25K Subscribers"
          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
        />
        <button
          onClick={async () => {
            if (!label.trim()) return;
            await upsert({ data: { code, label: label.trim(), achieved: false, position: (list.at(-1)?.position ?? 0) + 1 } });
            setLabel("");
            qc.invalidateQueries({ queryKey: ["milestones"] });
          }}
          className="rounded-xl px-4 py-2 text-sm font-medium text-white"
          style={{ background: "var(--gradient-red)" }}
        >
          Add
        </button>
      </div>
      <div className="space-y-2">
        {list.map((m) => (
          <div key={m.id} className="glass rounded-xl p-3 flex items-center gap-3">
            <input
              type="checkbox"
              checked={m.achieved}
              onChange={async (e) => {
                await upsert({ data: { code, id: m.id, label: m.label, achieved: e.target.checked, position: m.position } });
                qc.invalidateQueries({ queryKey: ["milestones"] });
              }}
            />
            <div className="flex-1 text-sm">{m.label}</div>
            <button
              onClick={async () => {
                if (!confirm("Delete?")) return;
                await del({ data: { code, id: m.id } });
                qc.invalidateQueries({ queryKey: ["milestones"] });
              }}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function CommentsTab({ code }: { code: string }) {
  const [username, setUsername] = useState("");
  const [comment, setComment] = useState("");
  const [avatar, setAvatar] = useState("");
  const [pinned, setPinned] = useState(true);
  const add = useServerFn(adminAddSpecialComment);
  const qc = useQueryClient();
  return (
    <div className="space-y-3">
      <h4 className="font-display font-semibold flex items-center gap-2">
        <Star className="h-4 w-4 text-primary" /> Add Special Comment
      </h4>
      <p className="text-xs text-muted-foreground">
        Special comments get a glowing red card and ride at the top of the wall. Delete or hide normal comments by hovering a comment card on the homepage.
      </p>
      <input
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Display name (e.g. Aaquif)"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
      />
      <textarea
        rows={3}
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Comment text…"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50 resize-none"
      />
      <input
        value={avatar}
        onChange={(e) => setAvatar(e.target.value)}
        placeholder="Avatar URL (optional)"
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
      />
      <label className="text-xs flex items-center gap-2">
        <input type="checkbox" checked={pinned} onChange={(e) => setPinned(e.target.checked)} /> Pin to top
      </label>
      <button
        onClick={async () => {
          if (!username.trim() || !comment.trim()) return;
          try {
            await add({ data: { code, username: username.trim(), comment: comment.trim(), avatar_url: avatar.trim() || null, pinned } });
            toast.success("Comment added");
            setUsername(""); setComment(""); setAvatar("");
            qc.invalidateQueries({ queryKey: ["comments"] });
          } catch (e) {
            toast.error((e as Error).message);
          }
        }}
        className="rounded-xl px-4 py-2 text-sm font-medium text-white inline-flex items-center gap-1.5"
        style={{ background: "var(--gradient-red)" }}
      >
        <Plus className="h-3.5 w-3.5" /> Add
      </button>
    </div>
  );
}

function MessagesTab({ code }: { code: string }) {
  const list = useServerFn(adminListMessages);
  const del = useServerFn(adminDeleteMessage);
  const q = useQuery({
    queryKey: ["admin_messages"],
    queryFn: () => list({ data: { code } }),
  });
  const qc = useQueryClient();
  return (
    <div className="space-y-3">
      <h4 className="font-display font-semibold flex items-center gap-2">
        <MessageSquare className="h-4 w-4 text-primary" /> Contact Inbox
      </h4>
      {q.isLoading && <div className="text-sm text-muted-foreground">Loading…</div>}
      {(q.data ?? []).length === 0 && !q.isLoading && (
        <div className="text-sm text-muted-foreground">No messages yet.</div>
      )}
      {(q.data ?? []).map((m) => (
        <div key={m.id} className="glass rounded-xl p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-sm font-medium">
                {m.username}
                <span className="rounded-full glass-red px-2 py-0.5 text-[10px] uppercase tracking-wider">
                  {m.topic}
                </span>
              </div>
              <div className="text-[11px] text-muted-foreground">
                {m.email} {m.discord ? `• ${m.discord}` : ""} • {timeAgo(m.created_at)}
              </div>
            </div>
            <button
              onClick={async () => {
                if (!confirm("Delete?")) return;
                await del({ data: { code, id: m.id } });
                qc.invalidateQueries({ queryKey: ["admin_messages"] });
              }}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-3 text-sm whitespace-pre-wrap text-foreground/90">{m.message}</p>
        </div>
      ))}
    </div>
  );
}

function SettingsTab({ code }: { code: string }) {
  const { data: settings } = useSettings();
  const upd = useServerFn(updateSetting);
  const qc = useQueryClient();

  const Section = <K extends "hero" | "about" | "social" | "stats">({
    title,
    keyName,
    fields,
  }: {
    title: string;
    keyName: K;
    fields: Array<{ key: string; label: string; long?: boolean }>;
  }) => {
    const obj = (settings?.[keyName] ?? {}) as Record<string, string>;
    const [draft, setDraft] = useState<Record<string, string>>(obj);
    return (
      <div className="glass rounded-2xl p-4 space-y-3">
        <div className="font-display font-semibold">{title}</div>
        {fields.map((f) =>
          f.long ? (
            <textarea
              key={f.key}
              rows={3}
              value={draft[f.key] ?? ""}
              onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })}
              placeholder={f.label}
              className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50 resize-none"
            />
          ) : (
            <input
              key={f.key}
              value={draft[f.key] ?? ""}
              onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })}
              placeholder={f.label}
              className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50"
            />
          ),
        )}
        <button
          onClick={async () => {
            try {
              await upd({ data: { code, key: keyName, value: draft } });
              toast.success(`${title} saved`);
              qc.invalidateQueries({ queryKey: ["site_settings"] });
            } catch (e) {
              toast.error((e as Error).message);
            }
          }}
          className="rounded-xl px-4 py-2 text-sm font-medium text-white"
          style={{ background: "var(--gradient-red)" }}
        >
          Save
        </button>
      </div>
    );
  };

  if (!settings) return <div className="text-sm text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-4">
      <Section
        title="Hero"
        keyName="hero"
        fields={[
          { key: "title", label: "Title" },
          { key: "subtitle", label: "Subtitle" },
          { key: "tagline", label: "Tagline", long: true },
        ]}
      />
      <Section
        title="About"
        keyName="about"
        fields={[
          { key: "heading", label: "Heading" },
          { key: "body", label: "Body", long: true },
          { key: "niche", label: "Niche (use • to separate)" },
          { key: "mission", label: "Mission" },
        ]}
      />
      <Section
        title="Social Links"
        keyName="social"
        fields={[
          { key: "youtube", label: "YouTube URL" },
          { key: "discord", label: "Discord URL" },
          { key: "instagram", label: "Instagram URL" },
        ]}
      />
      <Section
        title="Stats"
        keyName="stats"
        fields={[
          { key: "subscribers", label: "Subscribers (e.g. 12.4K)" },
          { key: "views", label: "Total Views (e.g. 1.2M)" },
          { key: "videos", label: "Videos (e.g. 86)" },
          { key: "discord", label: "Discord members (e.g. 3.1K)" },
          { key: "years", label: "Years active (e.g. 3)" },
        ]}
      />
    </div>
  );
}
