import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { readDb, writeDb } from "./db.server";
import { randomUUID } from "crypto";

const AdminBase = z.object({ code: z.string().min(1) });

async function admin() {
  const { isAdmin } = await import("./admin.server");
  return { isAdmin };
}

// ---------------- Verify ----------------
export const verifyAdmin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    return { ok: isAdmin(data.code) };
  });

// ---------------- Videos ----------------
function parseYouTubeId(url: string): string | null {
  const patterns = [
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export const addVideo = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.extend({ url: z.string().url() }).parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const id = parseYouTubeId(data.url);
    if (!id) throw new Error("Invalid YouTube URL");
    
    let title: string | null = null;
    let channel: string | null = null;
    try {
      const r = await fetch(
        `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${id}`)}&format=json`,
      );
      if (r.ok) {
        const j = (await r.json()) as { title?: string; author_name?: string };
        title = j.title ?? null;
        channel = j.author_name ?? null;
      }
    } catch {}
    const thumbnail = `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`;
    
    const db = readDb();
    const inserted = {
      id: randomUUID(),
      youtube_url: data.url,
      video_id: id,
      title,
      thumbnail,
      channel,
      created_at: new Date().toISOString()
    };
    db.videos.push(inserted);
    writeDb(db);
    return inserted;
  });

export const deleteVideo = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    db.videos = db.videos.filter(v => v.id !== data.id);
    writeDb(db);
    return { ok: true };
  });

// ---------------- Posts ----------------
export const addPost = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    AdminBase.extend({
      text: z.string().min(1).max(1000),
      image_url: z.string().url().optional().nullable(),
      link: z.string().url().optional().nullable(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    const inserted = {
      id: randomUUID(),
      text: data.text,
      image_url: data.image_url ?? null,
      link: data.link ?? null,
      like_count: 0,
      created_at: new Date().toISOString()
    };
    db.posts.push(inserted);
    writeDb(db);
    return inserted;
  });

export const deletePost = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    db.posts = db.posts.filter(p => p.id !== data.id);
    writeDb(db);
    return { ok: true };
  });

// ---------------- Settings (stats / social / about / hero) ----------------
export const updateSetting = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    AdminBase.extend({
      key: z.enum(["hero", "about", "social", "stats"]),
      value: z.record(z.string(), z.any()),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    
    const existing = db.site_settings.find(s => s.key === data.key);
    if (existing) {
      existing.value = data.value;
      existing.updated_at = new Date().toISOString();
    } else {
      db.site_settings.push({
        key: data.key,
        value: data.value,
        updated_at: new Date().toISOString()
      });
    }
    
    writeDb(db);
    return { ok: true };
  });

// ---------------- Comments admin ----------------
export const adminAddSpecialComment = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    AdminBase.extend({
      username: z.string().min(1).max(40),
      comment: z.string().min(1).max(400),
      avatar_url: z.string().url().optional().nullable(),
      pinned: z.boolean().optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    const ins = {
      id: randomUUID(),
      username: data.username,
      comment: data.comment,
      avatar_url: data.avatar_url ?? null,
      is_special: true,
      pinned: data.pinned ?? false,
      hidden: false,
      created_at: new Date().toISOString()
    };
    db.comments.push(ins);
    writeDb(db);
    return ins;
  });

export const adminCommentAction = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    AdminBase.extend({
      id: z.string().uuid(),
      action: z.enum(["delete", "pin", "unpin", "hide", "show"]),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    
    if (data.action === "delete") {
      db.comments = db.comments.filter(c => c.id !== data.id);
    } else {
      const c = db.comments.find(c => c.id === data.id);
      if (c) {
        if (data.action === "pin") c.pinned = true;
        if (data.action === "unpin") c.pinned = false;
        if (data.action === "hide") c.hidden = true;
        if (data.action === "show") c.hidden = false;
      }
    }
    writeDb(db);
    return { ok: true };
  });

// ---------------- Messages ----------------
export const adminListMessages = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    return [...db.messages].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  });

export const adminDeleteMessage = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    db.messages = db.messages.filter(m => m.id !== data.id);
    writeDb(db);
    return { ok: true };
  });

// ---------------- Milestones ----------------
export const adminUpsertMilestone = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    AdminBase.extend({
      id: z.string().uuid().optional(),
      label: z.string().min(1).max(80),
      achieved: z.boolean(),
      position: z.number().int().min(0).max(999),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    
    if (data.id) {
      const m = db.milestones.find(m => m.id === data.id);
      if (m) {
        m.label = data.label;
        m.achieved = data.achieved;
        m.position = data.position;
      }
    } else {
      db.milestones.push({
        id: randomUUID(),
        label: data.label,
        achieved: data.achieved,
        position: data.position
      });
    }
    writeDb(db);
    return { ok: true };
  });

export const adminDeleteMilestone = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AdminBase.extend({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { isAdmin } = await admin();
    if (!isAdmin(data.code)) throw new Error("Forbidden");
    const db = readDb();
    db.milestones = db.milestones.filter(m => m.id !== data.id);
    writeDb(db);
    return { ok: true };
  });
