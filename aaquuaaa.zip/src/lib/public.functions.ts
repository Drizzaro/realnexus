import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { readDb, writeDb } from "./db.server";
import { randomUUID } from "crypto";

// ---------------- Public Data Getters ----------------

export const getSettings = createServerFn({ method: "GET" }).handler(async () => {
  const db = readDb();
  return db.site_settings;
});

export const getVideos = createServerFn({ method: "GET" }).handler(async () => {
  const db = readDb();
  // Return sorted descending by created_at
  return [...db.videos].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
});

export const getPosts = createServerFn({ method: "GET" }).handler(async () => {
  const db = readDb();
  return [...db.posts].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
});

export const getComments = createServerFn({ method: "GET" }).handler(async () => {
  const db = readDb();
  // Sort pinned first, then by created_at
  return [...db.comments].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
});

export const getMilestones = createServerFn({ method: "GET" }).handler(async () => {
  const db = readDb();
  return [...db.milestones].sort((a, b) => a.position - b.position);
});

// ---------------- Public Mutations ----------------

export const addComment = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      username: z.string().min(1).max(40),
      comment: z.string().min(1).max(400),
    }).parse(d)
  )
  .handler(async ({ data }) => {
    const db = readDb();
    const newComment = {
      id: randomUUID(),
      username: data.username,
      comment: data.comment,
      avatar_url: null,
      pinned: false,
      hidden: false,
      is_special: false,
      created_at: new Date().toISOString()
    };
    db.comments.push(newComment);
    writeDb(db);
    return newComment;
  });

export const addMessage = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      name: z.string().min(1).max(80),
      email: z.string().email(),
      message: z.string().min(1).max(1000),
    }).parse(d)
  )
  .handler(async ({ data }) => {
    const db = readDb();
    const newMessage = {
      id: randomUUID(),
      name: data.name,
      email: data.email,
      message: data.message,
      created_at: new Date().toISOString()
    };
    db.messages.push(newMessage);
    writeDb(db);
    return newMessage;
  });
