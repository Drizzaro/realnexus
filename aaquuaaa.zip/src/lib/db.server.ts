import fs from "fs";
import path from "path";

export type DbData = {
  videos: any[];
  posts: any[];
  comments: any[];
  milestones: any[];
  site_settings: any[];
  messages: any[];
};

const DB_PATH = path.join(process.cwd(), "data.json");

function getInitialData(): DbData {
  return {
    videos: [],
    posts: [],
    comments: [
      {
        id: "c1",
        username: "Rahul Sharma",
        comment: "Bro your clutch in the last video was insane! 🔥",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      },
      {
        id: "c2",
        username: "Priya Patel",
        comment: "Waiting for the next SMP episode! When is it dropping?",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      },
      {
        id: "c3",
        username: "Aarav Singh",
        comment: "Best editing in the Minecraft community hands down.",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
      },
      {
        id: "c4",
        username: "Neha Gupta",
        comment: "Can I join your discord server? Huge fan!",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
      },
      {
        id: "c5",
        username: "Vikram Reddy",
        comment: "That base design is crazy. Taking notes for my own world.",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 96).toISOString(),
      },
      {
        id: "c6",
        username: "Aditya Verma",
        comment: "Bro, when are we getting the world tour video?!",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 100).toISOString(),
      },
      {
        id: "c7",
        username: "Sneha Nair",
        comment: "This is easily the best Minecraft channel. Your voiceovers are so chill.",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 120).toISOString(),
      },
      {
        id: "c8",
        username: "Karan Joshi",
        comment: "Are you planning to play hardcore anytime soon?",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 144).toISOString(),
      },
      {
        id: "c9",
        username: "Rohan Desai",
        comment: "The cinematic shots in this video gave me chills! Keep it up Aaquif! 👏",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 168).toISOString(),
      },
      {
        id: "c10",
        username: "Anjali Menon",
        comment: "Your building style is so unique. Absolutely love it.",
        avatar_url: null,
        pinned: false,
        hidden: false,
        is_special: false,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 200).toISOString(),
      }
    ],
    milestones: [
      { id: "m1", label: "1K Subs", achieved: true, position: 1 },
      { id: "m2", label: "10K Subs", achieved: true, position: 2 },
      { id: "m3", label: "50K Subs", achieved: false, position: 3 },
      { id: "m4", label: "100K Subs", achieved: false, position: 4 }
    ],
    site_settings: [],
    messages: [],
  };
}

export function readDb(): DbData {
  try {
    if (fs.existsSync(DB_PATH)) {
      const content = fs.readFileSync(DB_PATH, "utf-8");
      return JSON.parse(content) as DbData;
    }
  } catch (err) {
    console.error("Error reading db:", err);
  }
  return getInitialData();
}

export function writeDb(data: DbData) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing db:", err);
  }
}
