export interface SiteSettings {
  hero: { title: string; subtitle: string; tagline: string };
  about: { heading: string; body: string; niche: string; mission: string };
  social: { youtube: string; discord: string; instagram: string };
  stats: { subscribers: string; views: string; videos: string; discord: string; years: string };
}

export const DEFAULT_SETTINGS: SiteSettings = {
  hero: {
    title: "RealAaquif",
    subtitle: "Gaming • Minecraft • Content Creation",
    tagline: "Premium gaming content, built for the elite.",
  },
  about: {
    heading: "About RealAaquif",
    body:
      "RealAaquif is a Minecraft creator and gaming storyteller. From clutch survival runs to community-driven adventures, every video is built to feel cinematic, sharp, and personal.",
    niche: "Minecraft • Gameplay • Community",
    mission: "Build the warmest, sharpest gaming community on the internet.",
  },
  social: {
    youtube: "https://youtube.com/@RealAaquif",
    discord: "https://discord.gg/c3EJv5yvZC",
    instagram: "https://instagram.com/realaaquif",
  },
  stats: {
    subscribers: "13.6k",
    views: "900k",
    videos: "86",
    discord: "13.5k",
    years: "1",
  },
};

export function formatStat(v: string): string {
  return v;
}
