// Server-only. The admin code never reaches the client bundle.
// Change this value any time to rotate the admin secret.
export const ADMIN_CODE = "drizzarobsfaaquif";

export function isAdmin(code: unknown): code is string {
  return typeof code === "string" && code === ADMIN_CODE;
}
