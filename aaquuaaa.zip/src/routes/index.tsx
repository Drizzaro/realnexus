import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/portal/Header";
import { Hero } from "@/components/portal/Hero";
import { VideosSection } from "@/components/portal/VideosSection";
import { PostsSection } from "@/components/portal/PostsSection";
import { StatsSection } from "@/components/portal/StatsSection";
import { AboutSection } from "@/components/portal/AboutSection";
import { SocialSection } from "@/components/portal/SocialSection";
import { ContactSection } from "@/components/portal/ContactSection";
import { CommentsSection } from "@/components/portal/CommentsSection";
import { ChatWidget } from "@/components/portal/ChatWidget";
import { AdminPanel } from "@/components/portal/AdminPanel";
import { useSettings } from "@/hooks/usePortalData";
import { DEFAULT_SETTINGS } from "@/lib/portal-types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RealAaquif — Gaming • Minecraft • Content Creation" },
      {
        name: "description",
        content:
          "The official portal of RealAaquif — premium Minecraft and gaming content. Latest videos, community feed, milestones, and direct contact.",
      },
      { property: "og:title", content: "RealAaquif — Premium Gaming Creator" },
      {
        property: "og:description",
        content:
          "Premium Minecraft and gaming content, built for the elite. Watch the latest drops, join the Discord, follow the journey.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#0a0a0a" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "RealAaquif",
          description:
            "Minecraft creator and gaming storyteller. Cinematic gameplay, community-first content.",
          sameAs: [
            "https://youtube.com/@RealAaquif",
            "https://instagram.com/realaaquif",
          ],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { data: settings = DEFAULT_SETTINGS } = useSettings();
  return (
    <main className="relative">
      <Header />
      <Hero settings={settings} />
      <VideosSection />
      <PostsSection />
      <StatsSection settings={settings} />
      <AboutSection settings={settings} />
      <SocialSection settings={settings} />
      <CommentsSection />
      <ContactSection />
      <footer className="px-4 py-10 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} RealAaquif · Crafted with care
      </footer>
      <ChatWidget />
      <AdminPanel />
    </main>
  );
}
